import React, { useEffect, useState } from 'react'
import { socket } from '../socket';
import OnlineUsers from '../components/OnlineUsers';

const ChatRoom = ({ username }) => {
  const [inputMessage, setInputMessage] = useState("");
  const [messageList, setMessageList] = useState([]);
  const handleSendMessage = () => {
    if (inputMessage == "") return;
    setMessageList(prev => {
      const lastMessage = prev[prev.length - 1];
      if (lastMessage && lastMessage.sender == username) {
        return prev.map((elem, index) => {
          if (index != prev.length - 1) {
            return elem;
          } else {
            return { message: [...elem.message, inputMessage], sender: username }
          }
        })
      } else {
        return [...prev, { message: [inputMessage], sender: username }]
      }
    }

      // if (messageList[messageList.length - 1] && messageList[messageList.length - 1].sender == username) {
      //   return { message: [...elem.message, inputMessage], sender: username }
      // } else {
      //   return [...prev, { message: [inputMessage], sender: username }]
      // }


      // [...prev, { message: inputMessage, sender: username }]
    );
    socket.emit("message", { message: inputMessage, sender: username });
    setInputMessage("");
    console.log(messageList)
  }

  useEffect(() => {

    const addMessageInList = (msg) => {
      // setMessageList((prev) => [...prev, { message: msg.message, sender: msg.sender }]);

      setMessageList(prev => {
        const lastMessage = prev[prev.length - 1];
        if (lastMessage && lastMessage.sender == msg.sender) {
          return prev.map((elem, index) => {
            if (index != prev.length - 1) {
              return elem;
            } else {
              return { message: [...elem.message, msg.message], sender: lastMessage.sender }
            }
          })
        } else {
          return [...prev, { message: [msg.message], sender: msg.sender }]
        }
      })
      console.log(msg)
    }

    const addTypingUser = (users) => {

    }


    socket.on("message", addMessageInList);
    socket.on("typing_on", addTypingUser)
    return () => {

      socket.off("message", addMessageInList)
    };
  }, []);

  return (
    <div className='fullScreen grid place-items-center bg-yellow-100 relative px-3 py-7'>
      <div className='absolute hover:bg-black/5 right-2 top-2 px-3 py-1 rounded-md'>@{username}</div>
      <div className='bg-white border-2 w-full max-w-xl  border-black rounded-2xl h-full flex flex-col'>
        <div className='flex items-center border-b-2 justify-between h-10 px-3'>
          <h1 className='font-bold text-xl'>Chat Group</h1>
          <OnlineUsers />
        </div>
        <div className=' p-3 font-mono  cRCParent overflow-y-scroll'>
          {messageList.map(elem => elem.sender == username ? <SentMessage messagesList={elem.message} /> : <RecievedMessage sender={elem.sender} messagesList={elem.message} />)}
        </div>
        {/* <div className='text-sm px-2 typingAnim'>new, hell and i are typing...</div> */}
        <div className='flex items-center p-1 '>
          <input type="text" value={inputMessage} onKeyDown={(e) => { if (e.key == "Enter") { handleSendMessage() } }} onChange={(e) => setInputMessage(e.target.value)} placeholder='Enter message' className='flex-1 px-3 border-2 py-1 rounded-l-xl' />
          <button className='bg-green-300 h-full px-4 font-bold rounded-r-xl border-2 border-l-0' onClick={handleSendMessage}>Send</button>
        </div>
      </div>
    </div>
  )
}

const RecievedMessage = ({ sender, messagesList }) => {
  return (
    <div className="messageParent max-w-4/5 mb-2">
      <p className='text-[12px] mb-1'>@{sender}</p>
      {messagesList.map((elem, index) => <div className={'border-2 mb-0.5 bg-red-100 w-fit px-3 py-1 rounded-r-2xl ' + (index == 0 ? 'rounded-tl-2xl' : '') + (index == messagesList.length - 1 ? ' rounded-bl-2xl' : '')}>{elem}</div>)}
    </div>
  )
}

const SentMessage = ({ sender, messagesList }) => {
  return (
    <div className='w-full flex justify-end'>
      <div className="messageParent max-w-4/5 mb-2 flex flex-col items-end-safe">
        {messagesList.map((elem, index) => <div className={' border-2 mb-0.5 bg-blue-100 w-fit px-3 py-1 rounded-l-2xl ' + (index == 0 ? 'rounded-tr-2xl' : '') + (index == messagesList.length - 1 ? ' rounded-br-2xl' : '')}>{elem}</div>)}
      </div>
    </div>
  )
}


export default ChatRoom